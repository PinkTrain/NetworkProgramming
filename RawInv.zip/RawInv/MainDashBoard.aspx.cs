﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace RawInv
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //if (Session["New"] != null)
            //{
            //    lblWelcome.Text += Session["New"].ToString();
            //}
            //else
            //{
            //    Response.Redirect("Login.aspx");
            //}

            //string mainConnection = ConfigurationManager.ConnectionStrings["PeakPrintsDB"].ConnectionString;
            //SqlConnection sqlconn = new SqlConnection(mainConnection);
            //string sqlQuery = "SELECT * FROM [PeakPrintsDb].[dbo].[Products]";
            //SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlconn);
            //sqlconn.Open();
            //SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
            //DataTable dataTable = new DataTable();
            //adapter.Fill(dataTable);
            //GridView1.DataSourceID = null;
            //GridView1.DataSource = dataTable;
            //GridView1.DataBind();
            //sqlconn.Close();
        }

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Session["New"] = null;
            Response.Redirect("Login.aspx");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string chkSearch = "";
            for (int i=0; i < CheckBoxList1.Items.Count; i++)
            {
                if (CheckBoxList1.Items[i].Selected)
                {
                    if (chkSearch == "")
                    {
                        chkSearch = "'" + CheckBoxList1.Items[i].Text + "'";
                    }
                    else
                    {
                        chkSearch += ", " + CheckBoxList1.Items[i].Text;
                    }
                    lblSearch.Text = chkSearch;
                    lblSearch.Visible = false;

                    string mainConnection = ConfigurationManager.ConnectionStrings["PeakPrintsDB"].ConnectionString;
                    SqlConnection sqlconn = new SqlConnection(mainConnection);
                    string sqlQuery = "SELECT * FROM [PeakPrintsDb].[dbo].[Products] WHERE ProductName IN (" + lblSearch.Text + ")";
                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlconn);
                    sqlconn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    GridView1.DataSourceID = null;
                    GridView1.DataSource = dataTable;
                    GridView1.DataBind();
                    sqlconn.Close();
                }

            }
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            string chkYes = "";
            for (int i = 0; i < CheckBoxList2.Items.Count; i++)
            {
                if (CheckBoxList2.Items[i].Selected)
                {
                    if (chkYes == "")
                    {
                        chkYes = "'" + CheckBoxList2.Items[i].Text + "'";
                    }
                    chkYes = "YES";
                    lblYes.Text = chkYes;
                    lblYes.Visible = false;

                    string mainConnection = ConfigurationManager.ConnectionStrings["PeakPrintsDB"].ConnectionString;
                    SqlConnection sqlconn = new SqlConnection(mainConnection);
                    string sqlQuery = "SELECT * FROM [PeakPrintsDb].[dbo].[Products] WHERE ReOrder LIKE '%Yes'";
                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlconn);
                    sqlconn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    GridView1.DataSourceID = null;
                    GridView1.DataSource = dataTable;
                    GridView1.DataBind();
                    sqlconn.Close();
                }

            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            Session["ViewState"] = null;
            Response.Redirect("MainDashBoard.aspx");
        }
    }
}

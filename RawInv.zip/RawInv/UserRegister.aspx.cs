﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace RawInv
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
                conn.Open();
                string validateUser = "SELECT count(*) FROM UserData WHERE Username='" + txtUsername.Text + "'";//sql injection prevention
                SqlCommand command = new SqlCommand(validateUser, conn);
                int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                if (temp == 1)
                {
                    Response.Write("User already exists.");
                }
    
                conn.Close();

            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }


        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        //changed name to Submit Button
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Guid newGuid = Guid.NewGuid(); //creates a new GUID (Globally Unique ID) every time submit button is invoked. 

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["PeakPrintsDbConnectionString"].ConnectionString);
                conn.Open();
                string insertQry = "INSERT INTO UserData(ID, Username,Email,Password,Firstname,Lastname) VALUES (@ID ,@Uname ,@Email ,@Pass ,@Fname ,@Lname)";
                SqlCommand command = new SqlCommand(insertQry, conn);
                txtUsername.Focus();

                command.Parameters.AddWithValue("@ID", newGuid.ToString());
                command.Parameters.AddWithValue("@Uname", txtUsername.Text);
                command.Parameters.AddWithValue("@Email", txtEmail.Text);
                command.Parameters.AddWithValue("@Pass", txtPassword.Text);
                command.Parameters.AddWithValue("@Fname", txtFirstName.Text);
                command.Parameters.AddWithValue("@Lname", txtLastname.Text);

                command.ExecuteNonQuery();
                Response.Redirect("Login.aspx");

                Response.Write("Registration is successful!");
               
                conn.Close();
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.ToString());
            }
            //finally
            //{
            //    Response.Redirect("~/Login.aspx");
            //}
        }

        //protected void btnReset_Click(object sender, EventArgs e)

    }
}
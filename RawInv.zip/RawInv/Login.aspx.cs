﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace RawInv
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
        
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();
            string validateUser = "SELECT count(*) FROM UserData WHERE Username='" + txtUN.Text + "'";//sql injection prevention
            SqlCommand command = new SqlCommand(validateUser, conn);
            int temp = Convert.ToInt32(command.ExecuteScalar().ToString());

            conn.Close();

            if (temp == 1)
            {
                 conn.Open();
                 string checkPassword = "SELECT password from UserData WHERE Password= '" + txtPass.Text +"'";
                 SqlCommand passCommand = new SqlCommand(checkPassword, conn);
                string password = passCommand.ExecuteScalar().ToString().Replace(" ", "");
                
                if (password == txtPass.Text)
                {
                    Session["New"] = txtUN.Text;
                    Response.Write("Password is correct.");
                    Response.Redirect("MainDashBoard.aspx");
                }
                else
                {
                    Response.Write("Password is incorrect.");
                }

            }
            else
            {
                Response.Write("Username is incorrect.");
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserRegister.aspx");
        }
    }
}